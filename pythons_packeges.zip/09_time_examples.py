"""
time module — Basic to Advanced Examples
Run: python 09_time_examples.py
"""
import time

# ---------- BASIC ----------
print("---- BASIC ----")
print(time.time())          # seconds since epoch (float)
# time.sleep(2)               # pause execution for 2 seconds

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
t = time.localtime()             # struct_time in local timezone
print(time.strftime("%Y-%m-%d", t))

start = time.time()
for _ in range(1000000):    # some busy work
    pass
elapsed = time.time() - start
print(f"Elapsed: {elapsed:.4f} seconds")

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
start = time.perf_counter()     # high-resolution timer, best for benchmarking
for _ in range(1000000):
    pass
print(f"perf_counter elapsed: {time.perf_counter() - start:.4f} seconds")

print(f"process_time: {time.process_time():.4f}")   # CPU time used (excludes sleep)
