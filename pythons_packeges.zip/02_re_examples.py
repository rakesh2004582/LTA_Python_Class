"""
re module (Regular Expressions) — Basic to Advanced Examples
Run: python 02_re_examples.py
"""
import re

# ---------- BASIC ----------
print("---- BASIC ----")
print(re.match(r'Hello', "Hello World"))       # matches at start
print(re.search(r'World', "Hello World"))       # matches anywhere
print(re.fullmatch(r'Hello World', "Hello World"))  # whole string

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
print(re.findall(r'\d+', "I have 2 cats and 10 dogs"))   # ['2', '10']

print(re.sub(r'\s+', '_', "hello   world"))                # hello_world
print(re.sub(r'(\d+)', r'[\1]', "I have 5 apples"))          # I have [5] apples
print(re.split(r'[,;]', "a,b;c,d"))                            # ['a','b','c','d']

# Email validation example
pattern = r'^[\w.+-]+@[\w-]+\.[a-zA-Z]{2,}$'
print(bool(re.match(pattern, "user@example.com")))              # True

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
# Groups
m = re.search(r'(\w+)@(\w+)\.(\w+)', "contact: john@mail.com")
print(m.group(0), m.group(1), m.groups())

# Named groups
m2 = re.search(r'(?P<user>\w+)@(?P<domain>\w+)', "john@mail")
print(m2.group('user'), m2.groupdict())

# Compiling patterns (faster for repeated use)
compiled = re.compile(r'hello', re.IGNORECASE)
print(compiled.findall("Hello HELLO hello"))

# Lookahead / lookbehind
print(re.findall(r'\d+(?=px)', "10px 20em 30px"))    # ['10', '30']
print(re.findall(r'(?<=\$)\d+', "$50 and €40"))         # ['50']
print(re.findall(r'\d+(?!px)', "10px 20em"))              # ['20']
