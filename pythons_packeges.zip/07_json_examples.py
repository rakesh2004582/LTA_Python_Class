"""
json module — Basic to Advanced Examples
Run: python 07_json_examples.py
"""
import json
from datetime import datetime

# ---------- BASIC ----------
print("---- BASIC ----")
data = {"name": "John", "age": 30}
json_str = json.dumps(data)              # dict -> JSON string
print(json_str)
print(json.loads('{"name": "John"}'))      # JSON string -> dict

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
print(json.dumps(data, indent=4))                # pretty-print
print(json.dumps(data, sort_keys=True))            # sort keys alphabetically

with open('data.json', 'w') as f:
    json.dump(data, f)              # write dict directly to file

with open('data.json') as f:
    loaded = json.load(f)             # read JSON file into dict
print(loaded)

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")

# Custom encoder for non-serializable types (e.g., datetime)
def custom_encoder(obj):
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError("not serializable")

encoded = json.dumps({"time": datetime.now()}, default=custom_encoder)
print(encoded)

# Custom decoder
def custom_decoder(d):
    if 'time' in d:
        d['time'] = datetime.fromisoformat(d['time'])
    return d

decoded = json.loads(encoded, object_hook=custom_decoder)
print(decoded)
