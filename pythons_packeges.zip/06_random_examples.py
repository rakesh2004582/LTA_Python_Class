"""
random module — Basic to Advanced Examples
Run: python 06_random_examples.py
"""
import random
import secrets

# ---------- BASIC ----------
print("---- BASIC ----")
print(random.random())              # float between 0.0 and 1.0
print(random.randint(1, 10))          # random int, inclusive both ends
print(random.uniform(1.5, 5.5))         # random float in range

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
print(random.choice(['a', 'b', 'c']))            # pick one item
print(random.choices(['a', 'b', 'c'], k=5))        # pick with replacement
print(random.sample([1, 2, 3, 4, 5], k=3))           # pick without replacement

my_list = [1, 2, 3, 4, 5]
random.shuffle(my_list)                                # shuffle in place
print(my_list)

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
random.seed(42)                       # reproducible randomness for testing
print(random.random())

print(random.gauss(mu=0, sigma=1))     # normal (Gaussian) distribution
print(random.betavariate(2, 5))          # beta distribution

# Cryptographically secure random — use for passwords/tokens, NOT `random`
print(secrets.token_hex(16))
print(secrets.choice(['a', 'b', 'c']))
