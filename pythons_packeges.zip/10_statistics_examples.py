"""
statistics module — Basic to Advanced Examples
Run: python 10_statistics_examples.py
"""
import statistics as stats

data = [1, 2, 3, 4, 5, 5]

# ---------- BASIC ----------
print("---- BASIC ----")
print(stats.mean(data))       # 3.333... (average)
print(stats.median(data))       # 3.5 (middle value)
print(stats.mode(data))           # 5 (most common)

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
print(stats.stdev(data))       # sample standard deviation
print(stats.variance(data))      # sample variance
print(stats.pstdev(data))          # population standard deviation
print(stats.pvariance(data))         # population variance

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
print(stats.median_low(data))              # lower of two middle values
print(stats.median_high(data))               # higher of two middle values
print(stats.harmonic_mean(data))               # harmonic mean
print(stats.geometric_mean(data))                # geometric mean (3.8+)
print(stats.quantiles(data, n=4))                  # quartiles
print(stats.NormalDist(mu=0, sigma=1).pdf(0))        # normal distribution (3.8+)
