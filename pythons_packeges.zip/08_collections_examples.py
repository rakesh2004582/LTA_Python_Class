"""
collections module — Basic to Advanced Examples
Run: python 08_collections_examples.py
"""
from collections import Counter, defaultdict, namedtuple, deque, OrderedDict, ChainMap

# ---------- BASIC: Counter ----------
print("---- BASIC: Counter ----")
c = Counter(['a', 'b', 'a', 'c', 'a'])
print(c)                     # Counter({'a': 3, 'b': 1, 'c': 1})
print(c.most_common(2))        # [('a', 3), ('b', 1)]
print(c['a'])                    # 3

# ---------- BASIC: defaultdict ----------
print("\n---- BASIC: defaultdict ----")
d = defaultdict(list)
d['fruits'].append('apple')       # no KeyError even though key didn't exist
d['fruits'].append('banana')
print(d)

# ---------- INTERMEDIATE: namedtuple ----------
print("\n---- INTERMEDIATE: namedtuple ----")
Point = namedtuple('Point', ['x', 'y'])
p = Point(3, 4)
print(p.x, p.y)

# ---------- ADVANCED: deque ----------
print("\n---- ADVANCED: deque ----")
dq = deque([1, 2, 3])
dq.append(4)          # add to right
dq.appendleft(0)        # add to left
print(dq)
dq.pop()                  # remove from right
dq.popleft()                # remove from left
print(dq)                     # O(1) ops on both ends

# ---------- ADVANCED: OrderedDict, ChainMap ----------
print("\n---- ADVANCED: OrderedDict, ChainMap ----")
od = OrderedDict()
od['a'] = 1
od['b'] = 2
print(od)

cm = ChainMap({'a': 1}, {'b': 2})   # combine multiple dicts into one view
print(cm['a'])                        # looks through each dict in order
