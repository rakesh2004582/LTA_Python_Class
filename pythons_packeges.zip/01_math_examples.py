"""
math module — Basic to Advanced Examples
Run: python 01_math_examples.py
"""
import math

# ---------- BASIC ----------
print("---- BASIC ----")
print(math.sqrt(16))          # 4.0
print(math.pi)                 # 3.141592653589793
print(math.e)                   # 2.718281828459045
print(math.floor(4.7))           # 4
print(math.ceil(4.2))             # 5
print(math.fabs(-5))               # 5.0
print(math.factorial(5))            # 120

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
print(math.pow(2, 3))          # 8.0
print(math.log(100, 10))        # 2.0
print(math.log(math.e))          # 1.0
print(math.log2(8))               # 3.0
print(math.log10(1000))            # 3.0
print(math.exp(1))                  # 2.718...

print(math.sin(math.pi / 2))    # 1.0
print(math.cos(0))                # 1.0
print(math.degrees(math.pi))       # 180.0
print(math.radians(180))            # 3.14159...

print(math.gcd(12, 18))         # 6
print(math.hypot(3, 4))          # 5.0

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
print(math.isclose(0.1 + 0.2, 0.3))    # True
print(math.isnan(float('nan')))          # True
print(math.isinf(float('inf')))           # True
print(math.comb(5, 2))                      # 10
print(math.perm(5, 2))                       # 20
print(math.prod([1, 2, 3, 4]))                # 24
print(math.dist((0, 0), (3, 4)))               # 5.0
print(math.copysign(3, -1))                     # -3.0
print(math.remainder(9, 4))                      # 1.0
print(math.trunc(4.9))                            # 4
