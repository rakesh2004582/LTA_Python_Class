"""
sys module — Basic to Advanced Examples
Run: python 05_sys_examples.py
"""
import sys

# ---------- BASIC ----------
print("---- BASIC ----")
print(sys.argv)          # list of command-line arguments
print(sys.version)        # Python version string
print(sys.platform)        # 'linux', 'win32', 'darwin', etc.

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
print(sys.path[:3])                       # first few module search paths
print("this is an error message", file=sys.stderr)
# sys.exit(0)                              # exit the program with status code

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
print(sys.getsizeof([1, 2, 3]))     # memory size of an object in bytes
print(sys.maxsize)                    # largest Py_ssize_t value
# sys.setrecursionlimit(2000)          # change max recursion depth
print(len(sys.modules))                 # number of currently loaded modules
