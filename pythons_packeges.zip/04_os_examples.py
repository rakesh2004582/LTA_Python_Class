"""
os module — Basic to Advanced Examples
Run: python 04_os_examples.py
NOTE: Some lines (mkdir/remove) are commented out to avoid changing your
filesystem when you just run this to read the examples. Uncomment to try them.
"""
import os

# ---------- BASIC ----------
print("---- BASIC ----")
print(os.getcwd())                 # current working directory
print(os.listdir('.'))              # list files/folders here
print(os.path.exists('file.txt'))    # check if path exists

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
# os.mkdir('new_folder')             # create a directory
# os.makedirs('a/b/c')                # create nested directories
# os.rename('old.txt', 'new.txt')      # rename file
# os.remove('file.txt')                 # delete a file
# os.rmdir('empty_folder')               # delete empty directory

print(os.path.join('folder', 'file.txt'))     # OS-safe path joining
print(os.path.basename('/a/b/file.txt'))        # file.txt
print(os.path.dirname('/a/b/file.txt'))          # /a/b
print(os.path.splitext('file.txt'))               # ('file', '.txt')

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
print(os.environ.get('PATH'))       # read an environment variable
os.environ['MY_VAR'] = 'value'        # set an environment variable

for root, dirs, files in os.walk('.'):   # walk directory tree recursively
    print(root, dirs, files)
    break  # just show first level for demo

# os.system('echo hello')             # run a shell command
print(os.cpu_count())                  # number of CPUs available
