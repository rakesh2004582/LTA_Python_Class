"""
datetime module — Basic to Advanced Examples
Run: python 03_datetime_examples.py
"""
from datetime import datetime, date, timedelta, timezone
from zoneinfo import ZoneInfo

# ---------- BASIC ----------
print("---- BASIC ----")
print(datetime.now())               # current date & time
print(date.today())                  # current date only
print(datetime(2026, 9, 16))          # specific datetime
print(datetime(2026, 9, 16, 14, 30))   # with time

# ---------- INTERMEDIATE ----------
print("\n---- INTERMEDIATE ----")
now = datetime.now()
print(now.strftime("%Y-%m-%d"))              # 2026-09-16
print(now.strftime("%d/%m/%Y"))               # 16/09/2026
print(now.strftime("%H:%M:%S"))                # 14:30:00
print(now.strftime("%A, %B %d, %Y"))            # Wednesday, September 16, 2026

# Parsing strings into datetime
print(datetime.strptime("2026-09-16", "%Y-%m-%d"))
print(datetime.strptime("16/09/2026 14:30", "%d/%m/%Y %H:%M"))

# Arithmetic
today = date.today()
print(today + timedelta(days=1))          # tomorrow
print(today - timedelta(weeks=1))           # last week
diff = date(2026, 12, 31) - today
print(diff.days)                              # days remaining in year

# ---------- ADVANCED ----------
print("\n---- ADVANCED ----")
utc_now = datetime.now(timezone.utc)
print(utc_now)

ist = timezone(timedelta(hours=5, minutes=30))
print(datetime.now(ist))

india_time = datetime.now(ZoneInfo("Asia/Kolkata"))
print(india_time)

d1 = date(2026, 1, 1)
d2 = date(2026, 12, 31)
print(d1 < d2)                    # True
print(d1.replace(year=2027))       # change just one field
